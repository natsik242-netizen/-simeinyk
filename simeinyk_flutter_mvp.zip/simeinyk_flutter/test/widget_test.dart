import 'package:flutter_test/flutter_test.dart';
import 'package:simeinyk/main.dart';

void main() {
  testWidgets('Simeinyk launches', (tester) async {
    await tester.pumpWidget(const SimeinykApp());
    expect(find.text('Сімейник'), findsOneWidget);
  });
}
